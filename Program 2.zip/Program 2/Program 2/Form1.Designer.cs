﻿namespace Program_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstLetterTxt = new System.Windows.Forms.TextBox();
            this.firstLetterOfLastNameLbl = new System.Windows.Forms.Label();
            this.freshmanRb = new System.Windows.Forms.RadioButton();
            this.sophomoreRb = new System.Windows.Forms.RadioButton();
            this.juniorRb = new System.Windows.Forms.RadioButton();
            this.seniorRb = new System.Windows.Forms.RadioButton();
            this.classStandingLbl = new System.Windows.Forms.Label();
            this.earliestLbl = new System.Windows.Forms.Label();
            this.earliestCalculatedLbl = new System.Windows.Forms.Label();
            this.calculatedDateAndTimeBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // firstLetterTxt
            // 
            this.firstLetterTxt.Location = new System.Drawing.Point(436, 44);
            this.firstLetterTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.firstLetterTxt.Name = "firstLetterTxt";
            this.firstLetterTxt.Size = new System.Drawing.Size(64, 22);
            this.firstLetterTxt.TabIndex = 0;
            // 
            // firstLetterOfLastNameLbl
            // 
            this.firstLetterOfLastNameLbl.Location = new System.Drawing.Point(96, 44);
            this.firstLetterOfLastNameLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.firstLetterOfLastNameLbl.Name = "firstLetterOfLastNameLbl";
            this.firstLetterOfLastNameLbl.Size = new System.Drawing.Size(316, 28);
            this.firstLetterOfLastNameLbl.TabIndex = 1;
            this.firstLetterOfLastNameLbl.Text = "Please enter the first letter of you\'re last name:";
            // 
            // freshmanRb
            // 
            this.freshmanRb.AutoSize = true;
            this.freshmanRb.Location = new System.Drawing.Point(436, 112);
            this.freshmanRb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.freshmanRb.Name = "freshmanRb";
            this.freshmanRb.Size = new System.Drawing.Size(92, 21);
            this.freshmanRb.TabIndex = 2;
            this.freshmanRb.TabStop = true;
            this.freshmanRb.Text = "Freshman";
            this.freshmanRb.UseVisualStyleBackColor = true;
            // 
            // sophomoreRb
            // 
            this.sophomoreRb.AutoSize = true;
            this.sophomoreRb.Location = new System.Drawing.Point(436, 140);
            this.sophomoreRb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.sophomoreRb.Name = "sophomoreRb";
            this.sophomoreRb.Size = new System.Drawing.Size(102, 21);
            this.sophomoreRb.TabIndex = 3;
            this.sophomoreRb.TabStop = true;
            this.sophomoreRb.Text = "Sophomore";
            this.sophomoreRb.UseVisualStyleBackColor = true;
            // 
            // juniorRb
            // 
            this.juniorRb.AutoSize = true;
            this.juniorRb.Location = new System.Drawing.Point(436, 169);
            this.juniorRb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.juniorRb.Name = "juniorRb";
            this.juniorRb.Size = new System.Drawing.Size(68, 21);
            this.juniorRb.TabIndex = 4;
            this.juniorRb.TabStop = true;
            this.juniorRb.Text = "Junior";
            this.juniorRb.UseVisualStyleBackColor = true;
            // 
            // seniorRb
            // 
            this.seniorRb.AutoSize = true;
            this.seniorRb.Location = new System.Drawing.Point(436, 197);
            this.seniorRb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.seniorRb.Name = "seniorRb";
            this.seniorRb.Size = new System.Drawing.Size(70, 21);
            this.seniorRb.TabIndex = 5;
            this.seniorRb.TabStop = true;
            this.seniorRb.Text = "Senior";
            this.seniorRb.UseVisualStyleBackColor = true;
            // 
            // classStandingLbl
            // 
            this.classStandingLbl.Location = new System.Drawing.Point(96, 113);
            this.classStandingLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.classStandingLbl.Name = "classStandingLbl";
            this.classStandingLbl.Size = new System.Drawing.Size(196, 28);
            this.classStandingLbl.TabIndex = 6;
            this.classStandingLbl.Text = "Please select class standing:";
            // 
            // earliestLbl
            // 
            this.earliestLbl.Location = new System.Drawing.Point(96, 262);
            this.earliestLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.earliestLbl.Name = "earliestLbl";
            this.earliestLbl.Size = new System.Drawing.Size(219, 28);
            this.earliestLbl.TabIndex = 7;
            this.earliestLbl.Text = "Earliest date and time to register:";
            // 
            // earliestCalculatedLbl
            // 
            this.earliestCalculatedLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.earliestCalculatedLbl.Location = new System.Drawing.Point(354, 262);
            this.earliestCalculatedLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.earliestCalculatedLbl.Name = "earliestCalculatedLbl";
            this.earliestCalculatedLbl.Size = new System.Drawing.Size(244, 28);
            this.earliestCalculatedLbl.TabIndex = 8;
            // 
            // calculatedDateAndTimeBtn
            // 
            this.calculatedDateAndTimeBtn.Location = new System.Drawing.Point(277, 370);
            this.calculatedDateAndTimeBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.calculatedDateAndTimeBtn.Name = "calculatedDateAndTimeBtn";
            this.calculatedDateAndTimeBtn.Size = new System.Drawing.Size(167, 47);
            this.calculatedDateAndTimeBtn.TabIndex = 9;
            this.calculatedDateAndTimeBtn.Text = "Calculate Date and Time";
            this.calculatedDateAndTimeBtn.UseVisualStyleBackColor = true;
            this.calculatedDateAndTimeBtn.Click += new System.EventHandler(this.calculatedDateAndTimeBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(681, 481);
            this.Controls.Add(this.calculatedDateAndTimeBtn);
            this.Controls.Add(this.earliestCalculatedLbl);
            this.Controls.Add(this.earliestLbl);
            this.Controls.Add(this.classStandingLbl);
            this.Controls.Add(this.seniorRb);
            this.Controls.Add(this.juniorRb);
            this.Controls.Add(this.sophomoreRb);
            this.Controls.Add(this.freshmanRb);
            this.Controls.Add(this.firstLetterOfLastNameLbl);
            this.Controls.Add(this.firstLetterTxt);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Program 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox firstLetterTxt;
        private System.Windows.Forms.Label firstLetterOfLastNameLbl;
        private System.Windows.Forms.RadioButton freshmanRb;
        private System.Windows.Forms.RadioButton sophomoreRb;
        private System.Windows.Forms.RadioButton juniorRb;
        private System.Windows.Forms.RadioButton seniorRb;
        private System.Windows.Forms.Label classStandingLbl;
        private System.Windows.Forms.Label earliestLbl;
        private System.Windows.Forms.Label earliestCalculatedLbl;
        private System.Windows.Forms.Button calculatedDateAndTimeBtn;
    }
}

