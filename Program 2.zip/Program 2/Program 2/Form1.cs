﻿// B1773
// Program 2
// October 22, 2017
// CIS 199-75-4178
//This assignment explores the use of decision making logic and the creation of a GUI application.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Console;

namespace Program_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculatedDateAndTimeBtn_Click(object sender, EventArgs e)
        {
            //Declaring Variables 
            string time; // Variable holding time as a string
            string day; //Variable holding day as a string
            const string JUNIOR_DAY = "Monday, NOV 6 th"; // A constant variable holding the JUNIOR_DAY as a string
            const string SENIOR_DAY = "Friday, NOV 3 rd"; // A constant variable holding the SENIOR_DAY as a string
            const string FRESHMAN_DAY1 = "Thursday, NOV 9 th"; //a constant variable holding the first freshman day as a string
            const string FRESHMAN_DAY2 = "Friday, NOV 10 th"; //a constant variable holding the second freshamn day as a string.
            const string SOPHOMORE_DAY1 = "Tuesday, NOV 7 th"; // a constant variable holding the first sophomore day as a string.
            const string SOPHOMORE_DAY2 = "Wedensday, NOV 8 th"; // a constant variable holding the second sophomore day as a string.
            string Time1 = "8:30"; // A variable holding the 1st time as a string.
            string Time2 = "10:00"; // A variable holding the 2nd time as a string.
            string Time3 = "11:30"; // A variable holding the 3rd time as a string.
            string Time4 = "2:00"; // A variable holding the 4th time as a string.
            string Time5 = "4:00"; // A variable holding the 5th time as a string.
            char firstLetterOfLastName; // A variable holding the first letter of the users last name as a char.

            //Parsing the input and pulling out the first letter of last name and making it a lowercase letter.
            firstLetterOfLastName = firstLetterTxt.Text[0];
            firstLetterOfLastName = char.ToLower(firstLetterOfLastName);





            //Senior and Junior Days and Times
            if (seniorRb.Checked || juniorRb.Checked)
            {
                if (firstLetterOfLastName <= 'd')
                    time = Time2;
                else if (firstLetterOfLastName <= 'i')
                    time = Time3;
                else if (firstLetterOfLastName <= 'o')
                    time = Time4;
                else if (firstLetterOfLastName <= 's')
                    time = Time5;
                else time = Time1;

                if (seniorRb.Checked)
                    day = SENIOR_DAY;
                else
                    day = JUNIOR_DAY;
                
            }
            else
            {
                //freshman and sophomore times

                if (firstLetterOfLastName <= 'b')
                    time = Time3;
                else if (firstLetterOfLastName <= 'd')
                    time = Time4;
                else if (firstLetterOfLastName <= 'f')
                    time = Time5;
                else if (firstLetterOfLastName <= 'i')
                    time = Time1;
                else if (firstLetterOfLastName <= 'l')
                    time = Time2;
                else if (firstLetterOfLastName <= 'o')
                    time = Time3;
                else if (firstLetterOfLastName <= 's')
                    time = Time5;
                else if (firstLetterOfLastName <= 'v')
                    time = Time1;
                else time = Time2;
                
                //Freshman and Sophomore Days
                if (sophomoreRb.Checked)
                    if (firstLetterOfLastName <= 's' && firstLetterOfLastName >= 'g')
                        day = SOPHOMORE_DAY2;
                    else
                        day = SOPHOMORE_DAY1;
                else
                    if (firstLetterOfLastName <= 's' && firstLetterOfLastName >= 'g')
                    day = FRESHMAN_DAY2;
                else
                    day = FRESHMAN_DAY1;


               

                


            }
            //Output
            earliestCalculatedLbl.Text = ($"{day} at {time}");

























        } 
    }
}
